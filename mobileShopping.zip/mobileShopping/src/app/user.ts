export interface User {
    userId: number;
    userName: string;
    emailId: string;
    createPassword: string;
    confirmPassword: string;
    mobileNumber:string;
    usertype: string;
}
