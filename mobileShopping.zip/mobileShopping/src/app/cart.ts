export interface Cart {
    cId: number;
    userId: number;
    itemId: number;
    itemName: string;
    itemStorage: string;
    itemColour: string;
    quantity: string;
    userName: string;
    mobileNumber: string;
    address: string;
    
}