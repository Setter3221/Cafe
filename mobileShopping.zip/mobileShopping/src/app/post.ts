export interface Post {
    itemId: number;
    itemName: string;
    itemPrice: string;
    itemSpecification : string;
    itemStorage: string;
    itemColour: string;
    itemAvailability: string;
    itemImages:string;
}