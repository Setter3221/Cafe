﻿using GrabbitCodeFirst.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GrabbitCodeFirst.Repository.CustomerRepository
{
	public interface ICustomerRepository
	{
		Task<ActionResult<Customer>> AddCustomer(Customer customer);
		Task<ActionResult<IEnumerable<Customer>>> GetCustomerDetails();
		Task<ActionResult<Customer>> GetCustomerDetail(int cid);
		Task<ActionResult<Customer>> RemoveCustomer(int cid);
	}
}
