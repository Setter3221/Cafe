﻿using GrabbitCodeFirst.Models;
using GrabbitCodeFirst.Repository.CustomerRepository;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace GrabbitCodeFirst.Repository.CustomerRepository
{
	public class CustomerRepository : ICustomerRepository
	{
		private readonly GrabbitContext _context;
		private readonly ILogger<CustomerRepository> _logger;
		public CustomerRepository(GrabbitContext context, ILogger<CustomerRepository> logger)
		{
			_context = context;
			_logger = logger;
		}

		public async Task<ActionResult<IEnumerable<Customer>>> GetCustomerDetails()
		{
			return await _context.Customer.ToListAsync();
		}
		async Task<ActionResult<Customer>> ICustomerRepository.AddCustomer(Customer customer)
		{
			_context.Customer.Add(customer);
			await _context.SaveChangesAsync();
			_logger.LogInformation("Customer Added Successfully!!");
			return customer;
		}
		async Task<ActionResult<Customer>> ICustomerRepository.RemoveCustomer(int cid)
		{
			var customer = await _context.Customer.FindAsync(cid);

			if (customer == null)
			{
				throw new NullReferenceException("No Customer Found!!");
			}
			else
			{
				_context.Customer.Remove(customer);
				await _context.SaveChangesAsync();
				_logger.LogInformation("Customer Removed Successfully!!");
				return customer;
			}
		}
		async Task<ActionResult<Customer>> ICustomerRepository.GetCustomerDetail(int cid)
		{
			var customer = await _context.Customer.FindAsync(cid);
			if (customer == null)
			{
				throw new NullReferenceException("No Customer Found!!");
			}
			else return customer;
		}
	}
}
