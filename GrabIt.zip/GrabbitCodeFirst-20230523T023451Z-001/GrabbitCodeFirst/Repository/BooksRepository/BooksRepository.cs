﻿using GrabbitCodeFirst.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GrabbitCodeFirst.Repository.BooksRepository
{
	public class BooksRepository : IBooksRepository
	{
		private readonly GrabbitContext _context;
		public BooksRepository(GrabbitContext context)
		{
			_context = context;
		}

		public async Task<ActionResult<IEnumerable<Books>>> GetBookDetails()
		{
			return await _context.Books.ToListAsync();
		}
		async Task<ActionResult<Books>> IBooksRepository.AddBook(Books book)
		{
			_context.Books.Add(book);
			await _context.SaveChangesAsync();

			return book;
		}
		async Task<ActionResult<Books>> IBooksRepository.DeleteBook(int bid)
		{
			var book = await _context.Books.FindAsync(bid);

			if (book == null)
			{
				throw new NullReferenceException("No Book Found!!");
			}
			else
			{
				_context.Books.Remove(book);
				await _context.SaveChangesAsync();
				return book;
			}
		}
		async Task<ActionResult<Books>> IBooksRepository.GetBookDetail(int bid)
		{
			var book = await _context.Books.FindAsync(bid);
			if (book == null)
			{
				throw new NullReferenceException("No Book Found!!");
			}
			else return book;
		}
	}
}
