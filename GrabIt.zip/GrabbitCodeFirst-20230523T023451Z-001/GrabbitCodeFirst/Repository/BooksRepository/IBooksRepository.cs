﻿using GrabbitCodeFirst.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GrabbitCodeFirst.Repository.BooksRepository
{
	public interface IBooksRepository
	{
		Task<ActionResult<Books>> AddBook(Books book);
		Task<ActionResult<IEnumerable<Books>>> GetBookDetails();
		Task<ActionResult<Books>> GetBookDetail(int bid);
		Task<ActionResult<Books>> DeleteBook(int bid);
	}
}
