﻿using GrabbitCodeFirst.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GrabbitCodeFirst.Repository.UserDetailsRepository
{
    public interface IUserDetailsRepository
    {
        Task<ActionResult<UserDetails>> AddUser(UserDetails userDetails);
        Task<ActionResult<UserDetails>> UpdateUser(int id, UserDetails userDetails);
        Task<ActionResult<IEnumerable<UserDetails>>> GetUserDetails();
        Task<ActionResult<UserDetails>> GetUserDetails(int id);
        Task<ActionResult<UserDetails>> GetUserDetailsByEmailPwd(string EmailId, string Password);
        Task<ActionResult<UserDetails>> DeleteUser(int id);
    }
}
