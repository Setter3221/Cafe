﻿using GrabbitCodeFirst.Models;
using log4net.Core;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GrabbitCodeFirst.Repository.UserDetailsRepository
{
    public class UserDetailsRepository : IUserDetailsRepository
    {
        private readonly GrabbitContext _context;
        private readonly ILogger _logger;
        public UserDetailsRepository(GrabbitContext context, ILogger logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<ActionResult<IEnumerable<UserDetails>>> GetUserDetails()
        {
            return await _context.UserDetails.ToListAsync();
        }
        async Task<ActionResult<UserDetails>> IUserDetailsRepository.AddUser(UserDetails userDetails)
        {
            _context.UserDetails.Add(userDetails);
            await _context.SaveChangesAsync();
            //_logger.LogInformation("User Added Successfully");

            return userDetails;
        }
        async Task<ActionResult<UserDetails>> IUserDetailsRepository.DeleteUser(int id)
        {
            var userDetails = await _context.UserDetails.FindAsync(id);

            if (userDetails == null)
            {
                throw new NullReferenceException("No User Found!!");
            }
            else
            {
                _context.UserDetails.Remove(userDetails);
                await _context.SaveChangesAsync();
                //_logger.LogInformation("Deleted user successfully.");

                return userDetails;
            }
        }
        async Task<ActionResult<UserDetails>> IUserDetailsRepository.GetUserDetails(int id)
        {
            var userDetails = await _context.UserDetails.FindAsync(id);
            return userDetails;
        }
        public async Task<ActionResult<UserDetails>> GetUserDetailsByEmailPwd(string EmailId, string Password)
        {
            var user = await _context.UserDetails.FirstOrDefaultAsync(x => x.EmailId == EmailId && x.Password == Password);
            if (user != null)
            {
                return user;
            }
            return null;
        }
        Task<ActionResult<UserDetails>> IUserDetailsRepository.UpdateUser(int id, UserDetails userDetails)
        {
            throw new System.NotImplementedException();
        }
    }
}
