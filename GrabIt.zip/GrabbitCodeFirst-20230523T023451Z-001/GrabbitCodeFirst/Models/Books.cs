﻿using System.ComponentModel.DataAnnotations;

namespace GrabbitCodeFirst.Models
{
    public class Books
    {
        [Key]
        public int BookId { get; set; }
        [Required(ErrorMessage = "This field cannot be empty.")]
        public string BookName { get; set; }
        [Required(ErrorMessage = "This field cannot be empty.")]
        public string AuthorName { get; set; }
        [Required(ErrorMessage = "This field cannot be empty.")]
        public string Price { get; set; }
        public string Path { get; set; }  
    }
}
