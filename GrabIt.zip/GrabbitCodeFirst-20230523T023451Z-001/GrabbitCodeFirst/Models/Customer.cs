﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace GrabbitCodeFirst.Models
{
    public class Customer
    {
        [Key]
		public int PurchaseId { get; set; }
        [ForeignKey("CustomerId")]
        [Required(ErrorMessage = "This field cannot be empty.")]
        public int CustomerId { get; set; }
        [ForeignKey("BookId")]
        [Required(ErrorMessage = "This field cannot be empty.")]
        public string BookId { get; set; }
        [Required(ErrorMessage = "This field cannot be empty.")]
        public string DateOfPurchase { get; set; }
    }
}
