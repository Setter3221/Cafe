﻿using Microsoft.EntityFrameworkCore;
using static System.Reflection.Metadata.BlobBuilder;

namespace GrabbitCodeFirst.Models
{
    public class GrabbitContext : DbContext
    {
        public GrabbitContext(DbContextOptions<GrabbitContext> options)
           : base(options)
        {
        }
        public virtual DbSet<Books> Books { get; set; }

        public virtual DbSet<Customer> Customer { get; set; }

        public virtual DbSet<UserDetails> UserDetails { get; set; }
    }
}
