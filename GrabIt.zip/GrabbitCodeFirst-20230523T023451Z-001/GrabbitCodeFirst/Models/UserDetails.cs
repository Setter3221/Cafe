﻿using System.ComponentModel.DataAnnotations;

namespace GrabbitCodeFirst.Models
{
    public class UserDetails
    {
        [Key]
        public int CustomerId { get; set; }
        
        public string CustomerName { get; set; }
        [Required(ErrorMessage = "This field cannot be empty.")]
        public string EmailId { get; set; }
        [Required(ErrorMessage = "This field cannot be empty.")]
        [MaxLength(20)]
        [MinLength(5)]
        public string Password { get; set; }
        public string UserType { get; set; }
        public string DateOfBirth { get; set; }
        public string Gender { get; set; }
    }
}
