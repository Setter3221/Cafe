﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GrabbitCodeFirst.Models;
using Microsoft.Extensions.Logging;
using GrabbitCodeFirst.Repository.BooksRepository;
using log4net.Repository.Hierarchy;
using Microsoft.AspNetCore.Cors;

namespace GrabbitCodeFirst.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    [EnableCors("AllowAngularOrigins")]
    public class BooksController : ControllerBase
    {
        private readonly GrabbitContext _context;
        private readonly ILogger<BooksController> _logger;
        private readonly IBooksRepository _bookRepository;

        public BooksController(GrabbitContext context, ILogger<BooksController> logger, IBooksRepository bookRepository)
        {
            _context = context;
            _logger = logger;
            _bookRepository= bookRepository;
        }

        // GET: api/Books
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Books>>> GetBookDetails()
        {

            return await _bookRepository.GetBookDetails();
        }

        // GET: api/Books/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Books>> GetBookDetails(int bid)
        {
            try
            {
                return await _bookRepository.GetBookDetail(bid);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return NotFound();
            }

            //var books = await _context.Books.FindAsync(id);
            //
            //if (books == null)
            //{
            //    return NotFound();
            //}
            //
            //return books;
        }

        // PUT: api/Books/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutBooks(int id, Books books)
        {
            if (id != books.BookId)
            {
                return BadRequest();
            }

            _context.Entry(books).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BooksExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Books
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Books>> PostBooks(Books books)
        {
            _context.Books.Add(books);
            await _context.SaveChangesAsync();
            _logger.LogInformation("Book Added Successfully!!");
            return CreatedAtAction("GetBooks", new { id = books.BookId }, books);
        }

        // DELETE: api/Books/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Books>> DeleteBooks(int id)
        {
            var books = await _context.Books.FindAsync(id);
            if (books == null)
            {
                return NotFound();
            }

            _context.Books.Remove(books);
            await _context.SaveChangesAsync();

            return books;
        }

        private bool BooksExists(int id)
        {
            return _context.Books.Any(e => e.BookId == id);
        }
    }
}
