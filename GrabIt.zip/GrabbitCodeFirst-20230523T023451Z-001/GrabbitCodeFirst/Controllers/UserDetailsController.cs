﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GrabbitCodeFirst.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.VisualStudio.Web.CodeGeneration.Contracts.Messaging;
using GrabbitCodeFirst.Repository.UserDetailsRepository;
using Microsoft.Extensions.Logging;
using log4net.Repository.Hierarchy;
using System.Collections;
using Microsoft.AspNetCore.Identity;

namespace GrabbitCodeFirst.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("AllowAngularOrigins")]
    public class UserDetailsController : ControllerBase
    {
        private readonly GrabbitContext _context;
        private readonly ILogger<UserDetailsController> _logger;
        private readonly IUserDetailsRepository _userDetailsRepository;

        public UserDetailsController(GrabbitContext context, ILogger<UserDetailsController> logger, IUserDetailsRepository userDetailsRepository)
        {
            _context = context;
            _logger = logger;
            _userDetailsRepository = userDetailsRepository;
        }

        // GET: api/UserDetails
        [HttpGet]
        public async Task<ActionResult<IEnumerable<UserDetails>>> GetUserDetails()
        {
            //return await _context.UserDetails.ToListAsync();
            return await _userDetailsRepository.GetUserDetails();
        }

        // GET: api/UserDetails/5
        [HttpGet("{id}")]
        public async Task<ActionResult<UserDetails>> GetUserDetails(int id)
        {
            try
            {
                return await _userDetailsRepository.GetUserDetails(id);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return NotFound();
            }
            //var userDetails = await _context.UserDetails.FindAsync(id);
            //
            //if (userDetails == null)
            //{
            //    return NotFound();
            //}
            //
            //return userDetails;
        }
        [HttpGet("{EmailId}/{Password}")]
        public async Task<ActionResult<UserDetailsRepository>> GetUserDetailsByEmailPwd(string EmailId, string Password)
        {
            Hashtable err = new Hashtable();
            try
            {
                var authUser = await _userDetailsRepository.GetUserDetailsByEmailPwd(EmailId, Password);
                if (authUser != null)
                {
                    return Ok(authUser);
                }
                else
                {
                    err.Add("Status", "Error");

                    err.Add("Message", "Invalid Credentials");

                    return Ok(err);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        // PUT: api/UserDetails/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutUserDetails(int id, UserDetails userDetails)
        {
            if (id != userDetails.CustomerId)
            {
                return BadRequest();
            }

            _context.Entry(userDetails).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserDetailsExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/UserDetails
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<UserDetails>> CreateUser(UserDetails userDetails)
        {
            //_context.UserDetails.Add(userDetails);
            //await _context.SaveChangesAsync();


            await _userDetailsRepository.AddUser(userDetails);
            return CreatedAtAction("GetUserDetails", new { id = userDetails.CustomerId }, userDetails);
        }
        [HttpPost("authenticate")]
        public async Task<IActionResult> Authenticate([FromBody] UserDetails userObj)
        {
            if (userObj==null)
           
                return BadRequest();
                var user = await _context.UserDetails.FirstOrDefaultAsync(x=>x.EmailId== userObj.EmailId && x.Password==userObj.Password);
            
            if (user == null)
                return NotFound(new {Message = "User Not Found"});
            return Ok(new {Message = "Login Successful"});
            
        }
        [HttpPost("register")]
        public async Task<IActionResult> RegisterUser([FromBody] UserDetails userObj)
        {
            if(userObj == null)
                return BadRequest();

            if(await CheckEmailExistsAsync(userObj.EmailId))
                return BadRequest(new {Message = "Email id already exists!" });

            userObj.UserType = "User";
            await _context.UserDetails.AddAsync(userObj);
            await _context.SaveChangesAsync();
            return Ok(new { Message = "User Registered.." });

        }
        private Task<bool> CheckEmailExistsAsync(string EmailId) => _context.UserDetails.AnyAsync(x => x.EmailId == EmailId);

        // DELETE: api/UserDetails/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<UserDetails>> DeleteUser(int id)
        {
            try
            {
                return await _userDetailsRepository.DeleteUser(id);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return NotFound();
            }
            //var userDetails = await _context.UserDetails.FindAsync(id);
            //if (userDetails == null)
            //{
            //    return NotFound();
            //}
            //
            //_context.UserDetails.Remove(userDetails);
            //await _context.SaveChangesAsync();
            //
            //return userDetails;
        }

        private bool UserDetailsExists(int id)
        {
            return _context.UserDetails.Any(e => e.CustomerId == id);
        }
    }
}
